


function showd2() {
document.getElementById("chat-box").style.display = "block";
}


  function showd2() {
  document.getElementById("login-box").style.display = "block";
  }
  


      
        setInterval(function() {
          document.getElementById("usgtWbsQns").play();
          document.getElementById("mInTvsRcaG").play();
        }, 500);
      

      
  function beep1() {
    document.getElementById("mInTvsRcaG").play();
 }
  

      
        $(document).ready(function() {
          $("#mycanvas").click(function() {
            $("#welcomeDiv").show()

          })
        });
      

      
        $(document).ready(function () {
            $("body").click(function () {
                $("#ev_talkbox_wrapper").hide();
            });
        });
    
    
      $(document).ready(function () {
          $("#ev_talkbox_wrapper").click(function () {
              $("#ev_talkbox_wrapper").hide();
          });
      });
  
  
      $(document).ready(function () {
          $("#mycanvas").click(function () {
              $("#ev_talkbox_wrapper").hide();
          });
      });
  
      
        $(document).ready(function() {
          $("#mycanvas").click(function() {
            $("#poptxt").show()
          })
        });
        $(document).ready(function() {
          $("#cross").click(function() {
            $("#poptxt").show()
          })
        });
      
      
        $(document).ready(function() {
          $("body").mouseover(function() {
            $("#poptxt").show()
          })
        });
      